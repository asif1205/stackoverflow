// ================User Login ======================


const BASE_URL = "http://localhost:"; // Replace with your backend URL

async function loginUser(event) {
    event.preventDefault();
    
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;

    if (!username || !password) {
        alert("Please enter both username and password");
        return;
    }

    try {
        const res = await fetch(`${BASE_URL}8095/api/users/login`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ username, password })
        });

        if (!res.ok) throw new Error("Invalid credentials");

        const data = await res.json();
        localStorage.setItem("userToken", data.token); // save JWT
        alert("Login successful!");
        window.location.href = "../dashboard/user-dashboard.html"; // Redirect after login
    } catch (err) {
        alert(err.message);
    }
}
// ========================end======================



//======================Admin Login =============================



async function loginAdmin(event) {
    event.preventDefault();

    const username = document.getElementById("admin-username").value;
    const password = document.getElementById("admin-password").value;

    if (!username || !password) {
        alert("Please enter both username and password");
        return;
    }

    try {
        const res = await fetch(`${BASE_URL}8096/api/admin/login`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ username, password })
        });

        if (!res.ok) throw new Error("Invalid credentials");

        const data = await res.json();
        localStorage.setItem("adminToken", data.token); // save JWT
        alert("Admin login successful!");
        window.location.href = "../dashboard/admin-dashboard.html";
    } catch (err) {
        alert(err.message);
    }
}

//==========================End======================


//=======================User Register========================

async function registerUser(event) {
    event.preventDefault();

    const fullname = document.getElementById("fullname").value;
    const username = document.getElementById("username").value;
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;
    const confirmPassword = document.getElementById("confirm-password").value;

    if (!fullname || !username || !email || !password || !confirmPassword) {
        alert("Please fill all fields");
        return;
    }

    if (password !== confirmPassword) {
        alert("Passwords do not match");
        return;
    }

    try {
        const res = await fetch(`${BASE_URL}8095/api/users/register`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ fullname, username, email, password })
        });

        if (!res.ok) throw new Error("Registration failed");

        alert("Registration successful! Please login.");
        window.location.href = "user-login.html";
    } catch (err) {
        alert(err.message);
    }
}

//========================ENd=========================

//===================Admin register==================


async function registerAdmin(event) {
    event.preventDefault();

    const fullname = document.getElementById("fullname").value;
    const username = document.getElementById("username").value;
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;
    const confirmPassword = document.getElementById("confirm-password").value;
    const role = document.getElementById("role").value;
    const securityKey = document.getElementById("security-key").value;

    if (!fullname || !username || !email || !password || !confirmPassword || !role || !securityKey) {
        alert("Please fill all fields");
        return;
    }

    if (password !== confirmPassword) {
        alert("Passwords do not match");
        return;
    }

    try {
        const res = await fetch(`${BASE_URL}8096/api/admin/register`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ fullname, username, email, password, role, securityKey })
        });

        if (!res.ok) throw new Error("Admin registration failed");

        alert("Admin registration successful! Please login.");
        window.location.href = "admin-login.html";
    } catch (err) {
        alert(err.message);
    }
}

//=========================End==============================
