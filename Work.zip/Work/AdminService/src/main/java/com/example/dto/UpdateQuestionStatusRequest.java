package com.example.dto;

import org.antlr.v4.runtime.misc.NotNull;

import com.example.entity.QuestionStatus;

import lombok.Data;

@Data
public class UpdateQuestionStatusRequest {
    public UpdateQuestionStatusRequest(QuestionStatus status) {
		super();
		this.status = status;
	}

	public QuestionStatus getStatus() {
		return status;
	}

	public void setStatus(QuestionStatus status) {
		this.status = status;
	}

	@NotNull
    private QuestionStatus status;
}
