package com.example.config;

import java.util.List;

import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import com.example.security.JwtUtil;

import java.io.IOException; 

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;

@Component @RequiredArgsConstructor
public class JwtAuthFilter extends OncePerRequestFilter {
	
  public JwtAuthFilter(JwtUtil jwt) {
		super();
		this.jwt = jwt;
	}

  private final JwtUtil jwt;

  @Override protected void doFilterInternal(HttpServletRequest req, HttpServletResponse res, FilterChain chain)
    throws ServletException, IOException {
    String auth = req.getHeader("Authorization");
    if (auth != null && auth.startsWith("Bearer ")) {
      String token = auth.substring(7);
      try {
        var claims = jwt.validate(token);
        var authToken = new UsernamePasswordAuthenticationToken(
          claims.getSubject(), null, List.of(new SimpleGrantedAuthority("ROLE_"+claims.get("role", String.class))));
        SecurityContextHolder.getContext().setAuthentication(authToken);
      } catch (Exception ignore) {}
    }
    chain.doFilter(req, res);
  }
}

