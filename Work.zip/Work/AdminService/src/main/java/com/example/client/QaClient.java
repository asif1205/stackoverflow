package com.example.client;

import com.example.dto.ApproveRequest;
import com.example.dto.UpdateQuestionStatusRequest;
import com.example.entity.Answer;
import com.example.entity.Question;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@FeignClient(name = "qa-service", path = "/api/qa")
public interface QaClient {

    // --- Existing methods ---
    @GetMapping("/questions/pending")
    Page<Question> pending(@RequestParam int page, @RequestParam int size);

    @PutMapping("/questions/{id}/approval")
    Question approveQuestion(@PathVariable Long id, @RequestBody ApproveRequest req);

    @PutMapping("/answers/{id}/approval")
    Answer approveAnswer(@PathVariable Long id, @RequestBody ApproveRequest req);

    @PutMapping("/questions/{id}/status")
    Question setStatus(@PathVariable Long id, @RequestBody UpdateQuestionStatusRequest req);

    // --- New CRUD methods for Questions ---

    // Create a new question
    @PostMapping("/questions")
    Question createQuestion(@RequestBody Question question);

    // Get all questions
    @GetMapping("/questions")
    List<Question> getAllQuestions();

    // Get single question by ID
    @GetMapping("/questions/{id}")
    Question getQuestionById(@PathVariable Long id);

    // Update a question
    @PutMapping("/questions/{id}")
    Question updateQuestion(@PathVariable Long id, @RequestBody Question question);

    // Delete a question
    @DeleteMapping("/questions/{id}")
    void deleteQuestion(@PathVariable Long id);
}
