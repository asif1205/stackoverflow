package com.example.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.entity.Admin;
import com.example.repository.AdminRepository;
import com.google.common.base.Optional;

@Service
public class AdminService {

    @Autowired
    private AdminRepository adminRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    public Admin register(Admin admin) {
        // Hash password
        admin.setPassword(passwordEncoder.encode(admin.getPassword()));
        return adminRepository.save(admin);
    }

    public Admin login(String username, String password) {
        // Fetch user by username
        Optional<Admin> optionalUser = adminRepository.findByUsername(username);

        if (!optionalUser.isPresent()) {
            throw new RuntimeException("User not found");
        }

        Admin admin = optionalUser.get();

        // Check password
        if (!passwordEncoder.matches(password, admin.getPassword())) {
            throw new RuntimeException("Invalid credentials");
        }

        // Return user
        return admin;
    }

	

}
