package com.example.entity;

public enum QuestionStatus {
	OPEN, RESOLVED, CLOSED 
}
