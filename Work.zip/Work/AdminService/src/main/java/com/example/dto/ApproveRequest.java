package com.example.dto;

import org.antlr.v4.runtime.misc.NotNull;

import com.example.entity.ApprovalStatus;

import lombok.Data;


@Data
public class ApproveRequest {
    public ApproveRequest(Long id, ApprovalStatus approval) {
		super();
		this.id = id;
		this.approval = approval;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public ApprovalStatus getApproval() {
		return approval;
	}

	public void setApproval(ApprovalStatus approval) {
		this.approval = approval;
	}

	@NotNull
    private Long id;

    @NotNull
    private ApprovalStatus approval;
}
