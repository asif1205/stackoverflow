package com.example.controller;

import java.util.List;
import java.util.Map;

import org.apache.hc.core5.http.HttpStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.client.QaClient;
import com.example.dto.ApproveRequest;
import com.example.dto.LoginRequest;
import com.example.dto.UpdateQuestionStatusRequest;
import com.example.entity.Admin;
import com.example.entity.Answer;
import com.example.entity.ApprovalStatus;
import com.example.entity.Question;
import com.example.entity.QuestionStatus;
import com.example.security.JwtUtil;
import com.example.service.AdminService;

@RestController
@RequestMapping("/api/admins")
@CrossOrigin(origins = "*")
public class AdminController {

	@Autowired
	private AdminService adminService;
	
	@Autowired
	private QaClient qaClient;
	
	@Autowired
	private JwtUtil jwtUtil;

	@PostMapping("/test")
	public String gree() {
		return "This is for admin testing";
	}

	@PostMapping("/register")
	public ResponseEntity<Admin> register(@RequestBody Admin user) {
		Admin savedUser = adminService.register(user);
		System.out.println(savedUser + "this is admin");
		return ResponseEntity.ok(savedUser);
	}

	@PostMapping("/login")
	public ResponseEntity<?> login(@RequestBody LoginRequest req) {
	    try {
	        Admin admin = adminService.login(req.getUsername(), req.getPassword());

	        // generate JWT
	        String token = jwtUtil.generateToken(admin.getUsername(), "ADMIN");

	        // return token and user info (not password!)
	        return ResponseEntity.ok(Map.of(
	            "token", token,
	            "username", admin.getUsername(),
	            "role", "ADMIN"
	        ));
	    } catch (Exception e) {
	        return ResponseEntity.status(HttpStatus.SC_UNAUTHORIZED)
	                .body(Map.of("error", "Invalid username or password"));
	    }
	}


	@PostMapping("/moderation/questions/{id}/approve")
	public Question approveQ(@PathVariable Long id) {
		return qaClient.approveQuestion(id,new ApproveRequest(id,ApprovalStatus.APPROVED));
	}

	@PostMapping("/moderation/answers/{id}/approve")
	public Answer approveA(@PathVariable Long id) {
		return qaClient.approveAnswer(id, new ApproveRequest(id, ApprovalStatus.APPROVED));
	}

	@GetMapping("/moderation/questions/pending")
	public Page<Question> pendingQ(@RequestParam(defaultValue = "0") int page,
			@RequestParam(defaultValue = "10") int size) {
		return qaClient.pending(page, size);
	}

	@PostMapping("/moderation/questions/{id}/close")
	public Question closeQ(@PathVariable Long id) {
		return qaClient.setStatus(id, new UpdateQuestionStatusRequest(QuestionStatus.RESOLVED));
	}
	
	@PostMapping("/questions")
	public ResponseEntity<Question> addQuestion(@RequestBody Question question) {
	    Question savedQuestion = qaClient.createQuestion(question); // send to QA service or save via service
	    return ResponseEntity.ok(savedQuestion);
	}

	@GetMapping("/questions")
	public ResponseEntity<List<Question>> getAllQuestions() {
	    List<Question> questions = qaClient.getAllQuestions(); // get all questions
	    return ResponseEntity.ok(questions);
	}

	@PutMapping("/questions/{id}")
	public ResponseEntity<Question> updateQuestion(@PathVariable Long id, @RequestBody Question question) {
	    Question updated = qaClient.updateQuestion(id, question);
	    return ResponseEntity.ok(updated);
	}

	@DeleteMapping("/questions/{id}")
	public ResponseEntity<Void> deleteQuestion(@PathVariable Long id) {
	    qaClient.deleteQuestion(id);
	    return ResponseEntity.ok().build();
	}


}
