package com.example.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class CreateQuestionRequest {
    public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}

	public String getTags() {
		return tags;
	}

	public void setTags(String tags) {
		this.tags = tags;
	}

	public Long getAskedByUserId() {
		return askedByUserId;
	}

	public void setAskedByUserId(Long askedByUserId) {
		this.askedByUserId = askedByUserId;
	}

	@NotBlank
    private String title;

    @NotBlank
    private String body;

    private String tags;

    @NotNull
    private Long askedByUserId;

}
