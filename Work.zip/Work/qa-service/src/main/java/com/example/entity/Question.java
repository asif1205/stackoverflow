package com.example.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

//Question.java
@Entity @Data
public class Question {
public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getBody() {
		return body;
	}
	public void setBody(String body) {
		this.body = body;
	}
	public String getTags() {
		return tags;
	}
	public void setTags(String tags) {
		this.tags = tags;
	}
	public Long getAskedByUserId() {
		return askedByUserId;
	}
	public void setAskedByUserId(Long askedByUserId) {
		this.askedByUserId = askedByUserId;
	}
	public LocalDateTime getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}
	public QuestionStatus getStatus() {
		return status;
	}
	public void setStatus(QuestionStatus status) {
		this.status = status;
	}
	public ApprovalStatus getApproval() {
		return approval;
	}
	public void setApproval(ApprovalStatus approval) {
		this.approval = approval;
	}
	public boolean isActive() {
		return active;
	}
	public void setActive(boolean active) {
		this.active = active;
	}
@Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
private String title;
@Column(length = 5000) private String body;
private String tags; // CSV "java,spring,h2"
private Long askedByUserId;
private LocalDateTime createdAt = LocalDateTime.now();

@Enumerated(EnumType.STRING) private QuestionStatus status = QuestionStatus.OPEN;
@Enumerated(EnumType.STRING) private ApprovalStatus approval = ApprovalStatus.PENDING;
private boolean active = true; // soft delete / deactivate

}

