package com.example.service;

import java.time.LocalDateTime;
import java.util.Map;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.example.client.NotificationClient;
import com.example.dto.CreateAnswerRequest;
import com.example.dto.CreateCommentRequest;
import com.example.dto.CreateQuestionRequest;
import com.example.entity.Answer;
import com.example.entity.AnswerLike;
import com.example.entity.ApprovalStatus;
import com.example.entity.Comment;
import com.example.entity.Question;
import com.example.entity.QuestionStatus;
import com.example.repository.AnswerLikeRepository;
import com.example.repository.AnswerRepository;
import com.example.repository.CommentRepository;
import com.example.repository.QuestionRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class QAService {

    public QAService(QuestionRepository questionRepo, AnswerRepository answerRepo, CommentRepository commentRepo,
			AnswerLikeRepository likeRepo, NotificationClient notifier) {
		super();
		this.questionRepo = questionRepo;
		this.answerRepo = answerRepo;
		this.commentRepo = commentRepo;
		this.likeRepo = likeRepo;
		this.notifier = notifier;
	}

	private final QuestionRepository questionRepo;
    private final AnswerRepository answerRepo;
    private final CommentRepository commentRepo;
    private final AnswerLikeRepository likeRepo;
    private final NotificationClient notifier;

    public Question createQuestion(CreateQuestionRequest req) {
        Question q = new Question();
        q.setTitle(req.getTitle());
        q.setBody(req.getBody());
        q.setTags(req.getTags());
        q.setAskedByUserId(req.getAskedByUserId());
        q = questionRepo.save(q);

        notifier.newQuestion(Map.of(
                "questionId", q.getId(),
                "title", q.getTitle(),
                "askedBy", q.getAskedByUserId()));
        return q;
    }

    public Page<Question> search(String query, Pageable pageable) {
        return questionRepo.searchApproved(query == null ? "" : query, pageable);
    }

    public Answer addAnswer(CreateAnswerRequest req) {
        Answer a = new Answer();
        a.setQuestionId(req.getQuestionId());
        a.setBody(req.getBody());
        a.setAnsweredByUserId(req.getAnsweredByUserId());
        a = answerRepo.save(a);

        notifier.newAnswer(Map.of(
                "answerId", a.getId(),
                "questionId", a.getQuestionId(),
                "answeredBy", a.getAnsweredByUserId()
        ));
        return a;
    }

    public void likeAnswer(Long answerId, Long userId) {
        if (likeRepo.existsByAnswerIdAndLikedByUserId(answerId, userId)) return;
        likeRepo.save(new AnswerLike(null, answerId, userId, LocalDateTime.now()));
        Answer a = answerRepo.findById(answerId).orElseThrow();
        a.setLikeCount((int) likeRepo.countByAnswerId(answerId));
        answerRepo.save(a);
    }

    public Comment addComment(CreateCommentRequest req) {
        Comment c = new Comment();
        c.setAnswerId(req.getAnswerId());
        c.setText(req.getText());
        c.setCommentedByUserId(req.getCommentedByUserId());
        return commentRepo.save(c);
    }

    // Admin operations
    public Question approveQuestion(Long id, ApprovalStatus approval) {
        Question q = questionRepo.findById(id).orElseThrow();
        q.setApproval(approval);
        return questionRepo.save(q);
    }

    public Answer approveAnswer(Long id, ApprovalStatus approval) {
        Answer a = answerRepo.findById(id).orElseThrow();
        a.setApproval(approval);
        return answerRepo.save(a);
    }

    public Question updateStatus(Long id, QuestionStatus status) {
        Question q = questionRepo.findById(id).orElseThrow();
        q.setStatus(status);
        return questionRepo.save(q);
    }

    public void deactivateQuestion(Long id) {
        Question q = questionRepo.findById(id).orElseThrow();
        q.setActive(false);
        questionRepo.save(q);
    }

    public void deactivateAnswer(Long id) {
        Answer a = answerRepo.findById(id).orElseThrow();
        a.setActive(false);
        answerRepo.save(a);
    }
    
    public Question getQuestionById(Long id) {
        return questionRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Question not found with id " + id));
    }
    
    public Page<Question> getPendingQuestions(Pageable pageable) {
        return questionRepo.findByApproval(ApprovalStatus.PENDING, pageable);
    }


}
