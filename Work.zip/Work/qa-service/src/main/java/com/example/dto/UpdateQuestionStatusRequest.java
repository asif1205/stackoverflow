package com.example.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

import com.example.entity.QuestionStatus;

@Data
public class UpdateQuestionStatusRequest {
    public QuestionStatus getStatus() {
		return status;
	}

	public void setStatus(QuestionStatus status) {
		this.status = status;
	}

	@NotNull
    private QuestionStatus status;
}
