package com.example.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;

//Comment.java
@Entity @Data
public class Comment {
public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getAnswerId() {
		return answerId;
	}
	public void setAnswerId(Long answerId) {
		this.answerId = answerId;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public Long getCommentedByUserId() {
		return commentedByUserId;
	}
	public void setCommentedByUserId(Long commentedByUserId) {
		this.commentedByUserId = commentedByUserId;
	}
	public LocalDateTime getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}
	public boolean isActive() {
		return active;
	}
	public void setActive(boolean active) {
		this.active = active;
	}
@Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
private Long answerId;
@Column(length = 2000) private String text;
private Long commentedByUserId;
private LocalDateTime createdAt = LocalDateTime.now();
private boolean active = true;
}

