package com.example.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class CreateAnswerRequest {
    public Long getQuestionId() {
		return questionId;
	}

	public void setQuestionId(Long questionId) {
		this.questionId = questionId;
	}

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}

	public Long getAnsweredByUserId() {
		return answeredByUserId;
	}

	public void setAnsweredByUserId(Long answeredByUserId) {
		this.answeredByUserId = answeredByUserId;
	}

	@NotNull
    private Long questionId;

    @NotBlank
    private String body;

    @NotNull
    private Long answeredByUserId;
}
