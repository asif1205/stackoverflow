package com.example.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.entity.AnswerLike;

public interface AnswerLikeRepository extends JpaRepository<AnswerLike, Long> {
    boolean existsByAnswerIdAndLikedByUserId(Long answerId, Long userId);
    long countByAnswerId(Long answerId);
}
