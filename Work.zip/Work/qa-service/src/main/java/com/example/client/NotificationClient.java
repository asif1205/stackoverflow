package com.example.client;

import java.util.Map;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;

import io.swagger.v3.oas.annotations.parameters.RequestBody;

@FeignClient(name = "notification-service", path = "/api/notify")
public interface NotificationClient {
  @PostMapping("/new-question") void newQuestion(@RequestBody Map<String,Object> payload);
  @PostMapping("/new-answer") void newAnswer(@RequestBody Map<String,Object> payload);
}
