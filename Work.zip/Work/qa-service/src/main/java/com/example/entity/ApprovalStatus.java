package com.example.entity;

public enum ApprovalStatus { 
	PENDING, APPROVED, REJECTED 
}