package com.example.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.entity.ApprovalStatus;
import com.example.entity.Question;

public interface QuestionRepository extends JpaRepository<Question, Long> {

    @Query("""
        SELECT q FROM Question q
        WHERE q.active = true AND q.approval = 'APPROVED'
          AND (LOWER(q.title) LIKE LOWER(CONCAT('%', :q, '%'))
            OR LOWER(q.body) LIKE LOWER(CONCAT('%', :q, '%'))
            OR LOWER(q.tags) LIKE LOWER(CONCAT('%', :q, '%')))
    """)
    Page<Question> searchApproved(@Param("q") String query, Pageable pageable);

    Page<Question> findByApproval(ApprovalStatus status, Pageable pageable);
}
