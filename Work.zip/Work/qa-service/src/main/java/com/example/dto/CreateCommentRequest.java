package com.example.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class CreateCommentRequest {
    public Long getAnswerId() {
		return answerId;
	}

	public void setAnswerId(Long answerId) {
		this.answerId = answerId;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public Long getCommentedByUserId() {
		return commentedByUserId;
	}

	public void setCommentedByUserId(Long commentedByUserId) {
		this.commentedByUserId = commentedByUserId;
	}

	@NotNull
    private Long answerId;

    @NotBlank
    private String text;

    @NotNull
    private Long commentedByUserId;
}
