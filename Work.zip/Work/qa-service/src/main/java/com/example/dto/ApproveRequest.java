package com.example.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

import com.example.entity.ApprovalStatus;

@Data
public class ApproveRequest {
    public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public ApprovalStatus getApproval() {
		return approval;
	}

	public void setApproval(ApprovalStatus approval) {
		this.approval = approval;
	}

	@NotNull
    private Long id;

    @NotNull
    private ApprovalStatus approval;
}
