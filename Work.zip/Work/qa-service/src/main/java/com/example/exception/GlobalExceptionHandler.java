package com.example.exception;

import java.util.NoSuchElementException;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {
	@ExceptionHandler(NoSuchElementException.class)
	public ResponseEntity<?> notFound(NoSuchElementException e) {
		return ResponseEntity.status(404).body(e.getMessage());
	}

	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<?> badReq(MethodArgumentNotValidException e) {
		var msg = e.getBindingResult().getFieldErrors().stream()
				.map(fe -> fe.getField() + ": " + fe.getDefaultMessage()).toList();
		return ResponseEntity.badRequest().body(msg);
	}

	@ExceptionHandler(Exception.class)
	public ResponseEntity<?> generic(Exception e) {
		return ResponseEntity.status(500).body(e.getMessage());
	}
}
