package com.example.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.Data;

//AnswerLike.java
@Entity
@Table(uniqueConstraints = @UniqueConstraint(columnNames = { "answerId", "likedByUserId" }))
@Data
public class AnswerLike {
	public AnswerLike(Long id, Long answerId, Long likedByUserId, LocalDateTime createdAt) {
		super();
		this.id = id;
		this.answerId = answerId;
		this.likedByUserId = likedByUserId;
		this.createdAt = createdAt;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getAnswerId() {
		return answerId;
	}
	public void setAnswerId(Long answerId) {
		this.answerId = answerId;
	}
	public Long getLikedByUserId() {
		return likedByUserId;
	}
	public void setLikedByUserId(Long likedByUserId) {
		this.likedByUserId = likedByUserId;
	}
	public LocalDateTime getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private Long answerId;
	private Long likedByUserId;
	private LocalDateTime createdAt = LocalDateTime.now();
}
