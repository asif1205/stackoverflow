package com.example.repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.entity.Answer;
import com.example.entity.ApprovalStatus;

public interface AnswerRepository extends JpaRepository<Answer, Long> {
    List<Answer> findByQuestionIdAndActiveTrueAndApproval(Long questionId, ApprovalStatus approval);
}

