package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AwsEc2SpringBootAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(AwsEc2SpringBootAppApplication.class, args);
	}

}
