package com.example.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.entity.Admin;
import com.example.service.AdminService;

@RestController
@RequestMapping("/api/admins")
@CrossOrigin(origins = "*")
public class AdminController {

    @Autowired
    private AdminService adminService;
    
    @GetMapping("/test")
    public String gree() {
    	return "This is for admin testing";
    }
    @PostMapping("/register")
    public ResponseEntity<Admin> register(@RequestBody Admin user){
        Admin savedUser = adminService.register(user);
        System.out.println(savedUser+"this is admin");
        return ResponseEntity.ok(savedUser);
    }

    @PostMapping("/login")
    public ResponseEntity<Admin> login(@RequestBody Map<String, String> loginData){
        System.out.println("This is admin controller for login  "+loginData.get("username")+" : "+loginData.get("password"));
    	Admin user = adminService.login(loginData.get("username"), loginData.get("password"));
        System.out.println(user);
    	return ResponseEntity.ok(user);
    }
}
